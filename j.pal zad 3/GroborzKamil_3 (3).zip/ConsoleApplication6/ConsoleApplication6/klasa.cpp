#include "klasa.h"

void klasaB::metoda() {
	cout << "Metoda dla B" << endl;
	w1 = 1;
	w2 = 2;
	w3 = 3;
	w4 = 4;
	w5 = 5;
	w6 = 6;
	cout << "Zakonczenie metody B" << endl;
}

void klasaC::metoda1() {
	cout << "Metoda dla C" << endl;
	w1 = 1;
	w2 = 2;
	w3 = 3;
	w4 = 4;
	w5 = 5;
	w6 = 6;
	w7 = 7;
	w8 = 8;
	w9 = 9;
	cout << "Zakonczenie metody C" << endl;
}