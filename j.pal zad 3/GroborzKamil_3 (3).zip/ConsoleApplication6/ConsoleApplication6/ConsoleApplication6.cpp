﻿#include "klasa.h"

int main()
{
    klasaA a;
    klasaB b;
    klasaC c;
    int x;
    b.metoda();
    c.metoda1();

    x = a.w1;
    x = a.w2;
    x = a.w3;
    x = b.w1;
    x = b.w2;
    x = b.w3;
    x = b.w4;
    x = b.w5;
    x = b.w6;
    x = c.w1;
    x = c.w2;
    x = c.w3;
}
