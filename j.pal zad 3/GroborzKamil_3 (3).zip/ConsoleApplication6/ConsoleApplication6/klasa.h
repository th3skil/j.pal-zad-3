#include <iostream>
using namespace std;

class klasaA
{
private:
	int w1;
protected:
	int w2;
public:
	int w3;
};

class klasaB: private klasaA
{
private:
	int w4;
protected:
	int w5;
public:
	int w6;
	void metoda();
};

class klasaC : public klasaB
{
private:
	int w7;
protected:
	int w8;
public:
	int w9;
	void metoda1();
};

